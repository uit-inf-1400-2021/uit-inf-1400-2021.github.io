
class OddGenerator:

    def __init__(self, n):
        self.n = n
        self.odd = 1

    def __iter__(self):
        return self

    def __next__(self):
        if self.odd < self.n * 2:
            ret = self.odd
            self.odd += 2
            return ret
        else:
            raise StopIteration

if __name__ == "__main__":
    
    lst = [x for x in OddGenerator(4)]
    lst2 = [x for x in range(4*2) if x % 2 == 1]
    print(lst)
    print(lst2)