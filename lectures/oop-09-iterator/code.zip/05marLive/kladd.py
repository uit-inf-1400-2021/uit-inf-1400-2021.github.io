
letters = [l for l in "abcabcrabcdabccba" if l not in "abc"]

letters2 = []
for l in "abcabcrabcdabccba":
    if l not in "abc":
        letters2.append(l)


pairs = []
for x, y in zip([1, 2, 3], [4, 5, 6]):
    pairs.append((x, y))

#print(pairs)

newpairs = [(x, y) for x, y in zip([1, 2, 3], [4, 5, 6])]
#print(newpairs)

numbers = [(x, y) for x in [1, 2, 3] for y in [4, 2, 3] if x != y]
print(numbers)

numbers2 = []

for x in [1, 2, 3]:
    for y in [4, 2, 3]:
        if x != y:
            numbers2.append((x, y))

print(numbers2)








