
class AlphGenerator:

    memoized = []

    def __init__(self, n):
        self.n = n
        self.letter = "@"
        self.num = -1

    def next_alpha(self, s):
        return chr((ord(s)+1 - 65) % 26 + 65)

    def __iter__(self):
        return self

    def __next__(self):
        return self.next()

    def next(self):
        if self.num < self.n:
            self.num += 1
            if len(AlphGenerator.memoized) > self.num:
                print("Adding letter from memoized list")
                self.letter = AlphGenerator.memoized[self.num]
                return self.letter
            else:
                print("Unseen index, generating next")
                self.letter = self.next_alpha(self.letter)
                AlphGenerator.memoized.append(self.letter)
                return self.letter
        else:
            raise StopIteration



if __name__ == "__main__":
    letters = [l for l in AlphGenerator(5)]
    print(letters)

    print()

    moreLetters = [l for l in AlphGenerator(50)]
    print(moreLetters)

    moreLetters = [l for l in AlphGenerator(50)]
    print(moreLetters)
