
class VecList:

    def __init__(self, *args):
        self.vectors = []
        for vec in args:
            self.checkLegalElement(vec)
            self.vectors.append(vec)

    def __iter__(self):
        return self.vectors.__iter__()

    def __getitem__(self, idx):
        return self.vectors[idx]

    def __len__(self):
        return len(self.vectors)

    def append(self, vec):
        self.checkLegalElement(vec)
        self.vectors.append(vec)

    def remove(self, vec):
        self.vectors.remove(vec)

    def __str__(self):
        return self.vectors.__str__()

    def checkLegalElement(self, vec):
        if not type(vec) == tuple:
            raise TypeError("Attempted to add non-vector to VecList")
        for num in vec:
            if not (type(num) == int or type(num) == float):
                raise TypeError("Attempted to add non-vector to VecList")


if __name__ == "__main__":
    vectors = VecList((1, 2), (2, 1), (4, 3))
    print(vectors)
    vectors.append((2, 9))
    print(vectors)
    vectors.remove((1, 2))
    print(vectors)
    print("len vectors:", len(vectors))

    for e in vectors:
        x, y = e
        print("x:", x, "\ty:", y)
