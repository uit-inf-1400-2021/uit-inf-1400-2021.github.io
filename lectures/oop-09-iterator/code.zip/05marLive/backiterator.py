
class BackwardsList(list):

    def __init__(self):
        self.numElems = 0
        self.currentElem = 0

    def append(self, item):
        list.append(self, item)
        self.numElems += 1

    def __iter__(self):
        self.currentElem = self.numElems - 1
        return self

    def __next__(self):
        if self.currentElem >= 0:
            try:
                return self[self.currentElem]
            except:
                raise StopIteration
            finally:
                self.currentElem -= 1
        else:
            raise StopIteration

if __name__ == "__main__":
    lst = BackwardsList()
    lst.append("deg")
    lst.append("på")
    lst.append("hei")

    for word in lst:
        print(word)

    for word in lst:
        print(word)




