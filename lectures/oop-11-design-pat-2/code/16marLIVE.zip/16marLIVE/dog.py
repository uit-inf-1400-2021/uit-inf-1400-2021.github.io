from PIL import Image
from numpy import asarray


class Dog:

    labradorImage = asarray(Image.open("labrador.png"))
    goldenImage = asarray(Image.open("golden.png"))

    def __init__(self, breed, gender, height):
        self.breed = breed
        self.gender = gender
        self.height = height
        self.breedImage = self.loadImage()

    def loadImage(self):
        if self.breed == "labrador":
            image = Dog.labradorImage
        elif self.breed == "golden":
            image = Dog.goldenImage
        return image

    def __str__(self):
        return "Breed: " + self.breed + " gender: " + self.gender \
            + " height: " + str(self.height)


if __name__ == "__main__":
    dog = Dog("golden", "female", 50)
    print(dog)
    print(dog.breedImage)
