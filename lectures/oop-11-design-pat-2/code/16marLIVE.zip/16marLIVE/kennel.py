from poordog import PoorDog
from dog import Dog
from random import uniform, choice
import os
import psutil

if __name__ == "__main__":
    dogs = []
    breeds = ["golden", "labrador"]
    genders = ["male", "female"]
    for i in range(10000):
        breed = choice(breeds)
        gender = choice(genders)
        height = uniform(40, 60)
        dogs.append(Dog(breed, gender, height))
    
    print(psutil.Process(os.getpid()).memory_info().rss /
          1024 ** 2, "MBs of memory used")
