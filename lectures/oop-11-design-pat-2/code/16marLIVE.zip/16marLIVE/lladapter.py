from mylinkedlist import LinkedList

class LLAdapter:

    def __init__(self, *args):
        self.linkedlist = LinkedList(*args)

    def append(self, elem):
        self.linkedlist.insert(elem)

    def remove(self, elem):
        self.linkedlist.delete(elem)

    def __getitem__(self, idx):
        return self.linkedlist.getElemAtIdx(idx)

    def __setitem__(self, idx, data):
        self.linkedlist.setElemAtIdx(idx, data)

    def __str__(self):
        return self.linkedlist.__str__()