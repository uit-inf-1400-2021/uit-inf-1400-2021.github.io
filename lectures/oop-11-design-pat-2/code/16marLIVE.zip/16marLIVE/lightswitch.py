
# Light-class
class Light:

    def turnOn(self):
        print("Light is ON")

    def turnOff(self):
        print("Light is OFF")

# Command interface
class ICommand:

    def execute(self):
        print("You're not supposed to make instances of ICommand!")
        quit()

# Command 1
class CommandOn(ICommand):

    def __init__(self, light):
        self.light = light

    def execute(self):
        self.light.turnOn()

# Command 2
class CommandOff(ICommand):

    def __init__(self, light):
        self.light = light
    
    def execute(self):
        self.light.turnOff()

# Invoker
class Switch:

    def __init__(self):
        self.commands = {}
        self.commandQueue = []
        self.history = []
        self.lastCommandNumber = 0

    def register(self, commandName, command):
        self.commands[commandName] = command

    def queueCommand(self, commandName):
        self.commandQueue.append(commandName)

    def executeQueuedCommands(self):
        for com in self.commandQueue:
            self.execute(com)
        self.commandQueue = []

    def execute(self, commandName):
        if commandName in self.commands:
            self.commands[commandName].execute()
            self.history.append(commandName)
            self.lastCommandNumber += 1
        else:
            raise ValueError(commandName + "is an unknown command.")

    def undo(self):
        self.commands[self.history[-2]].execute()
        self.lastCommandNumber -= 2

    def redo(self):
        self.commands[self.history[self.lastCommandNumber + 1]].execute()
        self.lastCommandNumber += 1

    def getHistory(self):
        return self.history

if __name__ == "__main__":
    light = Light()

    # Create invoker
    switch = Switch()

    # Create commands
    switchOn = CommandOn(light)
    switchOff = CommandOff(light)

    # Register commands on invoker
    switch.register("ON", switchOn)
    switch.register("OFF", switchOff)

    # Test code
    switch.queueCommand("ON")
    switch.queueCommand("OFF")
    switch.queueCommand("OFF")
    switch.queueCommand("ON")

    switch.executeQueuedCommands()
