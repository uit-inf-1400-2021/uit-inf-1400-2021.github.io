from PIL import Image
from numpy import asarray

class PoorDog:

    def __init__(self, breed, gender, height):
        self.breed = breed
        self.gender = gender
        self.height = height
        self.breedImage = self.loadImage()

    def loadImage(self):
        imgfile = Image.open(self.breed + ".png")
        image = asarray(imgfile)
        imgfile.close()
        return image
    
    def __str__(self):
        return "Breed: " + self.breed + " gender: " + self.gender \
            + " height: " + str(self.height)

if __name__ == "__main__":
    dog = PoorDog("golden", "female", 50)
    print(dog)
    print(dog.breedImage)