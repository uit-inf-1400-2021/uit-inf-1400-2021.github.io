
class MyStack(list):

    def __init__(self):
        super()

    def __getitem__(self, idx):
        neg_idx = list.__len__(self) - 1 - idx
        return list.__getitem__(self, neg_idx)

    def __str__(self):
        l = list(self)
        s = l.__str__()
        s = s[::-1]
        s = "[" + s[1:-1] + "]"
        return s
    
    def put(self, elem):
        list.append(self, elem)
    
    def pop(self):
        elem = self.__getitem__(0)
        self.remove(self.__getitem__(0))
        return elem


a = MyStack()
a.put(1)
a.put(2)
a.put(3)

print(a)