from math import sqrt

def normalise(vec):
    magnitude = sqrt(vec[0]**2 + vec[1]**2)
    vec = [vec[0] / magnitude, vec[1] / magnitude] 

vec = [3, 4]
normalise(vec)
print(vec)
