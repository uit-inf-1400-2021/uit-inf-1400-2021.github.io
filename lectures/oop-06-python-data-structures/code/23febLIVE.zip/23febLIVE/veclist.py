
class Veclist:
    def __init__(self, *args):
        self.vectors = []
        for vec in args:
            self.checkLegalArgument(vec)
            self.vectors.append(vec)

    def __iter__(self):
        return self.vectors.__iter__()

    def __getitem__(self, idx):
        return self.vectors[idx]
    
    def __len__(self):
        return len(self.vectors)

    def __str__(self):
        return self.vectors.__str__()

    def append(self, vec):
        self.checkLegalArgument(vec)
        self.vectors.append(vec)

    def checkLegalArgument(self, vec):
        if not type(vec) == tuple:
            raise TypeError("Attempted to add non-tuple in Veclist")
        if not len(vec) == 2:
            raise ValueError("Veclist takes 2-tuples only")
        for num in vec:
            if not (type(num) == int or type(num) == float):
                raise TypeError("Attempted to add tuple with non-number")



vectors = Veclist((1, 2), (2, 3))
vectors.append((10, 12))

print(vectors)