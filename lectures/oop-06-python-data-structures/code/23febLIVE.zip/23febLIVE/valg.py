
def tellStemmer(stemmer):
    partier = {}
    for stemme in stemmer:
        if stemme not in partier:
            partier[stemme] = 1
        else:
            partier[stemme] += 1
    return partier

valgfil = open("valg.txt", "r")
stemmer = valgfil.readlines()
resultat = tellStemmer(stemmer)
for parti in resultat:
    print(parti, "stemmer:", resultat[parti])