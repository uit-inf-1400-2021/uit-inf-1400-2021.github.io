import pickle

class Scoreboard:

    def __init__(self):
        self.persons = []
        self.scores = []

    def insert(self, person, score):
        if not (type(person) == str and type(score) == int):
            raise TypeError("Person must be str, score must be int.")
        idx = 0
        while idx < len(self.scores) and self.scores[idx] > score:
            idx += 1
        self.persons.insert(idx, person)
        self.scores.insert(idx, score)

    def __getitem__(self, person):
        for p, s in zip(self.persons, self.scores):
            if person == p:
                return (p, s)
        return None

    def __len__(self):
        return len(self.persons)

    def __str__(self):
        ret = ""
        for p, s in zip(self.persons, self.scores):
            ret += p + ":\t" + str(s) + "\n"
        return ret

def dump_scoreboard(board):
    with open("myscoreboard.txt", "wb") as f:
        pickle.dump(board, f)

def fetch_scoreboard():
    board = None
    with open("myscoreboard.txt", "rb") as f:
        board = pickle.load(f)
    return board


if __name__ == "__main__":
    board = Scoreboard()
    board.insert("Arne", 12)
    board.insert("Berit", 15)
    board.insert("Geir", 20)
    board.insert("Ole", 3)
    board.insert("Lisa", 13)

    """print(board["Berit"])
    print(len(board))
    print(board)"""

    dump_scoreboard(board)
    b = fetch_scoreboard()

    print(b)
