from scoreboard import Scoreboard, fetch_scoreboard

if __name__ == "__main__":
    board = fetch_scoreboard()
    print(board)