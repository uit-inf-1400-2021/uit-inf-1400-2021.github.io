
a = "formatting"
b = 12

print(f"{a} text is hard")
print("{} text is hard".format(a))
print("%s text is hard" % a)
