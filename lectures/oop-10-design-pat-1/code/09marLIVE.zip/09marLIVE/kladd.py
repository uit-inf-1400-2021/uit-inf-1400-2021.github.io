
class AbstractSubscriber:

    def __init__(self, name):
        self.name = name

    def receive(self, message):
        print(self.name, "got message:", message)

class EmailSubscriber(AbstractSubscriber):

    def __init__(self, name):
        super().__init__(name)


class TraditionalSubscriber(AbstractSubscriber):

    def __init__(self, name):
        super().__init__(name)
        self.receive = self.fetchMail

    def fetchMail(self, mail):
        print(self.name, "got a letter saying:", mail)



class Publisher:

    def __init__(self):
        self.subscribers = {}

    def addSubscriber(self, sub, callback=None):
        if callback == None:
            callback = getattr(sub, "receive")
        self.subscribers[sub] = callback

    def pushNews(self, message):
        for sub, callback in self.subscribers.items():
            callback(message)


if __name__ == "__main__":
    arne = EmailSubscriber("Arne")
    berit = EmailSubscriber("Berit")
    caroline = EmailSubscriber("Caroline")
    kjell = TraditionalSubscriber("Grandpa Kjell")

    boss = Publisher()
    boss.addSubscriber(arne)
    boss.addSubscriber(berit)
    boss.addSubscriber(caroline)
    boss.addSubscriber(kjell)

    boss.pushNews("Gratis godis på Eurospar")
