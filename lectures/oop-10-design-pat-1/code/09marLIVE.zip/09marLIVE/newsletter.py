
class EmailSubscriber:

    def __init__(self, name):
        self.name = name
    
    def receive(self, message):
        print(self.name, "got the message:", message)

class TraditionalSubscriber:

    def __init__(self, name):
        self.name = name

    def fetchMail(self, mail):
        print(self.name, "got a letter saying:", mail)

class PhoneSubscriber:

    def __init__(self, name):
        self.name = name
    
    def pickUpPhoneAndReceiveThatOffer(self, offer):
        print(self.name, "got a great offer:", offer)

class Publisher:

    def __init__(self):
        self.subscribers = {}

    def addSubscriber(self, sub, callback=None):
        if callback == None:
            callback = getattr(sub, "receive")
        self.subscribers[sub] = callback
    
    def pushNews(self, message):
        for sub, callback in self.subscribers.items():
            callback(message)

if __name__ == "__main__":
    arne = EmailSubscriber("Arne")
    berit = EmailSubscriber("Berit")
    caroline = EmailSubscriber("Caroline")
    kjell = TraditionalSubscriber("Grandpa Kjell")
    ellen = PhoneSubscriber("Grandma Ellen")

    boss = Publisher()
    boss.addSubscriber(arne)
    boss.addSubscriber(berit)
    boss.addSubscriber(caroline)
    boss.addSubscriber(kjell, callback=kjell.fetchMail)
    boss.addSubscriber(ellen, callback=ellen.pickUpPhoneAndReceiveThatOffer)

    boss.pushNews("Gratis godis på Eurospar")
