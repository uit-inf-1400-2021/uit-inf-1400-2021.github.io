from insertionsort import insertionSort
from bubblesort import bubbleSort
from quicksort import quickSort

class superSort:

    def __init__(self, lst):
        self.insertionSort = insertionSort
        self.bubbleSort = bubbleSort
        self.quickSort = quickSort
        self.lst = lst
        self.sort()

    def sort(self):
        if len(self.lst) < 20:
            print("Chose bubblesort")
            self.bubbleSort(self.lst)
        elif len(self.lst) < 100:
            print("Chose insertion sort")
            self.insertionSort(self.lst)
        else:
            print("Chose quickSort")
            self.quickSort(self.lst, 0, len(self.lst)-1)

if __name__ == "__main__":
    words = open("sowpods_shuffled.txt", "r").readlines()[:50]
    superSort(words)

