from insertionsort import insertionSort
from bubblesort import bubbleSort
from quicksort import quickSort
from supersort import superSort
import time
import copy

def time_call(fn):
    def wrapper(*args, **kwargs):
        now = time.time()
        print("Running function", fn.__name__)
        fn(*args, **kwargs)
        print("Call took", time.time() - now, "seconds.")
    return wrapper

if __name__ == "__main__":
    words = open("sowpods_shuffled.txt", "r").readlines()[:100]
    
    quickSort = time_call(quickSort)
    bubbleSort = time_call(bubbleSort)
    insertionSort = time_call(insertionSort)
    superSort = time_call(superSort)
    sorted = time_call(sorted)

    bubbleSort(copy.deepcopy(words))
    insertionSort(copy.deepcopy(words))
    quickSort(copy.deepcopy(words), 0, len(words)-1)
    superSort(copy.deepcopy(words))
    sorted(copy.deepcopy(words))
